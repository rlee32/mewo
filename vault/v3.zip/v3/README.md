Main usage:  

run.py

Script explanations:  

1. plot_forces.py: plots the forces output by OpenFOAM.  
  1. gnuplot_script.sh: makes graphical plot.  
2. convert_mesh.sh: converts the mesh in the bridge to the current case.  
3. modify_boundary.py: needs to be run after mesh conversion.  
4. clean_times.py:  
5. start_over.py:  




