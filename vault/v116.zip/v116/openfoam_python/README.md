# openfoam_python

Some Python utilities I found useful in manipulating OpenFOAM cases 
in automated simulation procedures.

